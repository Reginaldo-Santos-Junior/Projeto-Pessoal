function opcao1(){

    texto.innerHTML = `<p>Caso tenha esquecido sua senha, acesse <a target="_blank" class="active" href="..//.html">"Esqueceu sua senha?"</a></p> `
}

function opcao2(){

    texto.innerHTML = `<p>Entre em contato diretamente com a nossa equipe a qualquer momento.<br><br>
        <strong> Instagram: </strong> <a target="_blank" class="active" href="https://instagram.com/sun_bean2022?igshid=YmMyMTA2M2Y="> "Clique Aqui!" </a><br>
            <strong> Facebook: </strong> <a target="_blank" class="active" href="https://www.facebook.com/Sun-Bean-107283795294201"> "Clique Aqui!" </a><br>
            <strong> E-Mail: </strong> <a target="_blank" class="active" href=""> "Clique Aqui!" </a></p>`
}

function opcao3(){

    texto.innerHTML = `<p>Para Acessar a página de monitoramento, você precisa seguir os seguintes passos.<br><br>
    1.Se você não possui uma conta, <a target="_blank" class="active" href="../Cadastro/cadastro.html"> "Cadastre-se!"</a><br>
    2.Depois de ter criado sua conta, entre na página de <a target="_blank" class="active" href="../Login/login.html"> "Login" </a><br>
    3.Após efetuar o login, você será automaticamente direcionado a página de Monitoramento.</p>`
}